from __future__ import annotations

from typing import TYPE_CHECKING, Any

if TYPE_CHECKING:
    from ..account import BmgAccount
else:
    BmgAccount = Any

from ..models import RankEntry


class RankingAPI:
    """Global, clan, gold/diamond, and per-game leaderboards."""

    __slots__ = ("_account",)

    def __init__(self, account: BmgAccount):
        self._account = account

    def get_user_rank(self, uid: int, rank_type: str = "active", rank_kind: str = "overall", is_region: bool = False) -> dict[str, Any]:
        return self._account.request("GET", "/ranking/api/v1/ranking/user/info",
                                     params={"rankType": rank_type, "type": rank_kind, "isRegion": "true" if is_region else "false"})

    def get_global_weekly(self, page: int = 1, size: int = 10) -> list[RankEntry]:
        r = self._account.request("GET", "/ranking/api/v1/active/global/weekly/rank", params={"pageNo": page, "pageSize": size})
        data = r.get("data")
        if isinstance(data, dict):
            items = data.get("data") or []
        elif isinstance(data, list):
            items = data
        else:
            items = []
        return [e for e in (RankEntry.from_dict(d) for d in items if d) if e is not None]

    def get_game_ranking(self, game_id: str, period: str = "all", page: int = 1, size: int = 10) -> dict[str, Any]:
        return self._account.get_game_ranking(game_id, period, page, size)

    def get_ranking_list(self, rank_type: str = "active", page: int = 1, size: int = 10) -> dict[str, Any]:
        return self._account.request("GET", "/ranking/api/v1/ranking/list",
                                     params={"rankType": rank_type, "pageNo": page, "pageSize": size})

    def get_friend_ranking(self, page: int = 1, size: int = 10) -> dict[str, Any]:
        return self._account.request("GET", "/ranking/api/v1/ranking/friends",
                                     params={"pageNo": page, "pageSize": size})

    def get_clan_ranking(self, rank_type: str = "active", page: int = 1, size: int = 10) -> dict[str, Any]:
        return self._account.request("GET", "/ranking/api/v1/ranking/clan",
                                     params={"rankType": rank_type, "pageNo": page, "pageSize": size})

    def get_global_overall(self, page: int = 1, size: int = 10) -> dict[str, Any]:
        return self._account.request("GET", "/ranking/api/v1/active/global/overall/rank",
                                     params={"pageNo": page, "pageSize": size})

    def get_region_weekly(self, page: int = 1, size: int = 10) -> dict[str, Any]:
        return self._account.request("GET", "/ranking/api/v1/active/region/weekly/rank",
                                     params={"pageNo": page, "pageSize": size})

    def get_region_overall(self, page: int = 1, size: int = 10) -> dict[str, Any]:
        return self._account.request("GET", "/ranking/api/v1/active/region/overall/rank",
                                     params={"pageNo": page, "pageSize": size})

    def get_clan_global_weekly(self, page: int = 1, size: int = 10) -> dict[str, Any]:
        return self._account.request("GET", "/ranking/api/v1/clan/global/weekly/rank",
                                     params={"pageNo": page, "pageSize": size})

    def get_clan_global_overall(self, page: int = 1, size: int = 10) -> dict[str, Any]:
        return self._account.request("GET", "/ranking/api/v1/clan/global/overall/rank",
                                     params={"pageNo": page, "pageSize": size})

    def get_clan_region_weekly(self, page: int = 1, size: int = 10) -> dict[str, Any]:
        return self._account.request("GET", "/ranking/api/v1/clan/region/weekly/rank",
                                     params={"pageNo": page, "pageSize": size})

    def get_clan_region_overall(self, page: int = 1, size: int = 10) -> dict[str, Any]:
        return self._account.request("GET", "/ranking/api/v1/clan/region/overall/rank",
                                     params={"pageNo": page, "pageSize": size})

    def get_gold_diamond_global_weekly(self, page: int = 1, size: int = 10) -> dict[str, Any]:
        return self._account.request("GET", "/ranking/api/v1/gold/diamond/global/weekly/rank",
                                     params={"pageNo": page, "pageSize": size})

    def get_gold_diamond_global_overall(self, page: int = 1, size: int = 10) -> dict[str, Any]:
        return self._account.request("GET", "/ranking/api/v1/gold/diamond/global/overall/rank",
                                     params={"pageNo": page, "pageSize": size})

    def get_gold_diamond_region_overall(self, page: int = 1, size: int = 10) -> list[RankEntry]:
        r = self._account.request("GET", "/ranking/api/v1/gold/diamond/region/overall/rank", params={"pageNo": page, "pageSize": size})
        data = r.get("data")
        if isinstance(data, dict):
            items = data.get("data") or []
        elif isinstance(data, list):
            items = data
        else:
            items = []
        return [e for e in (RankEntry.from_dict(d) for d in items if d) if e is not None]

    def get_gold_diamond_region_weekly(self, page: int = 1, size: int = 10) -> list[RankEntry]:
        r = self._account.request("GET", "/ranking/api/v1/gold/diamond/region/weekly/rank", params={"pageNo": page, "pageSize": size})
        data = r.get("data")
        if isinstance(data, dict):
            items = data.get("data") or []
        elif isinstance(data, list):
            items = data
        else:
            items = []
        return [e for e in (RankEntry.from_dict(d) for d in items if d) if e is not None]

    def get_region_home_page_info(self, rank_type: str = "active") -> dict[str, Any]:
        return self._account.request("GET", "/ranking/api/v1/ranking/region/home/page/info",
                                     params={"rankType": rank_type})

    async def async_get_user_rank(self, uid: int, rank_type: str = "active", rank_kind: str = "overall", is_region: bool = False) -> dict[str, Any]:
        return await self._account.async_request("GET", "/ranking/api/v1/ranking/user/info",
                                                 params={"rankType": rank_type, "type": rank_kind, "isRegion": "true" if is_region else "false"})

    async def async_get_global_weekly(self, page: int = 1, size: int = 10) -> list[RankEntry]:
        r = await self._account.async_request("GET", "/ranking/api/v1/active/global/weekly/rank", params={"pageNo": page, "pageSize": size})
        data = r.get("data")
        if isinstance(data, dict):
            items = data.get("data") or []
        elif isinstance(data, list):
            items = data
        else:
            items = []
        return [e for e in (RankEntry.from_dict(d) for d in items if d) if e is not None]

    async def async_get_game_ranking(self, game_id: str, period: str = "all", page: int = 1, size: int = 10) -> dict[str, Any]:
        return await self._account.async_get_game_ranking(game_id, period, page, size)

    async def async_get_ranking_list(self, rank_type: str = "active", page: int = 1, size: int = 10) -> dict[str, Any]:
        return await self._account.async_request("GET", "/ranking/api/v1/ranking/list",
                                                 params={"rankType": rank_type, "pageNo": page, "pageSize": size})

    async def async_get_friend_ranking(self, page: int = 1, size: int = 10) -> dict[str, Any]:
        return await self._account.async_request("GET", "/ranking/api/v1/ranking/friends",
                                                 params={"pageNo": page, "pageSize": size})

    async def async_get_clan_ranking(self, rank_type: str = "active", page: int = 1, size: int = 10) -> dict[str, Any]:
        return await self._account.async_request("GET", "/ranking/api/v1/ranking/clan",
                                                 params={"rankType": rank_type, "pageNo": page, "pageSize": size})

    async def async_get_global_overall(self, page: int = 1, size: int = 10) -> dict[str, Any]:
        return await self._account.async_request("GET", "/ranking/api/v1/active/global/overall/rank",
                                                 params={"pageNo": page, "pageSize": size})

    async def async_get_region_weekly(self, page: int = 1, size: int = 10) -> dict[str, Any]:
        return await self._account.async_request("GET", "/ranking/api/v1/active/region/weekly/rank",
                                                 params={"pageNo": page, "pageSize": size})

    async def async_get_region_overall(self, page: int = 1, size: int = 10) -> dict[str, Any]:
        return await self._account.async_request("GET", "/ranking/api/v1/active/region/overall/rank",
                                                 params={"pageNo": page, "pageSize": size})

    async def async_get_clan_global_weekly(self, page: int = 1, size: int = 10) -> dict[str, Any]:
        return await self._account.async_request("GET", "/ranking/api/v1/clan/global/weekly/rank",
                                                 params={"pageNo": page, "pageSize": size})

    async def async_get_clan_global_overall(self, page: int = 1, size: int = 10) -> dict[str, Any]:
        return await self._account.async_request("GET", "/ranking/api/v1/clan/global/overall/rank",
                                                 params={"pageNo": page, "pageSize": size})

    async def async_get_clan_region_weekly(self, page: int = 1, size: int = 10) -> dict[str, Any]:
        return await self._account.async_request("GET", "/ranking/api/v1/clan/region/weekly/rank",
                                                 params={"pageNo": page, "pageSize": size})

    async def async_get_clan_region_overall(self, page: int = 1, size: int = 10) -> dict[str, Any]:
        return await self._account.async_request("GET", "/ranking/api/v1/clan/region/overall/rank",
                                                 params={"pageNo": page, "pageSize": size})

    async def async_get_gold_diamond_global_weekly(self, page: int = 1, size: int = 10) -> dict[str, Any]:
        return await self._account.async_request("GET", "/ranking/api/v1/gold/diamond/global/weekly/rank",
                                                 params={"pageNo": page, "pageSize": size})

    async def async_get_gold_diamond_global_overall(self, page: int = 1, size: int = 10) -> dict[str, Any]:
        return await self._account.async_request("GET", "/ranking/api/v1/gold/diamond/global/overall/rank",
                                                 params={"pageNo": page, "pageSize": size})

    async def async_get_gold_diamond_region_overall(self, page: int = 1, size: int = 10) -> list[RankEntry]:
        r = await self._account.async_request("GET", "/ranking/api/v1/gold/diamond/region/overall/rank", params={"pageNo": page, "pageSize": size})
        data = r.get("data")
        if isinstance(data, dict):
            items = data.get("data") or []
        elif isinstance(data, list):
            items = data
        else:
            items = []
        return [e for e in (RankEntry.from_dict(d) for d in items if d) if e is not None]

    async def async_get_gold_diamond_region_weekly(self, page: int = 1, size: int = 10) -> list[RankEntry]:
        r = await self._account.async_request("GET", "/ranking/api/v1/gold/diamond/region/weekly/rank", params={"pageNo": page, "pageSize": size})
        data = r.get("data")
        if isinstance(data, dict):
            items = data.get("data") or []
        elif isinstance(data, list):
            items = data
        else:
            items = []
        return [e for e in (RankEntry.from_dict(d) for d in items if d) if e is not None]

    async def async_get_region_home_page_info(self, rank_type: str = "active") -> dict[str, Any]:
        return await self._account.async_request("GET", "/ranking/api/v1/ranking/region/home/page/info",
                                                 params={"rankType": rank_type})

    def get_game_leaderboard(self, game_id: str, period: str = "all", page: int = 0,
                             size: int = 10, game_version: int | None = None,
                             language: str = "en_US") -> dict[str, Any]:
        return self._account.game.get_game_leaderboard(game_id, period, page, size, game_version, language)

    async def async_get_game_leaderboard(self, game_id: str, period: str = "all", page: int = 0,
                                         size: int = 10, game_version: int | None = None,
                                         language: str = "en_US") -> dict[str, Any]:
        return await self._account.game.async_get_game_leaderboard(game_id, period, page, size, game_version, language)

    def get_game_usage_leaderboard(self, game_id: str, period: str = "all",
                                   language: str = "en_US") -> dict[str, Any]:
        return self._account.game.get_game_usage_leaderboard(game_id, period, language)

    async def async_get_game_usage_leaderboard(self, game_id: str, period: str = "all",
                                               language: str = "en_US") -> dict[str, Any]:
        return await self._account.game.async_get_game_usage_leaderboard(game_id, period, language)

    def get_game_my_rank(self, game_id: str, period: str = "all",
                         language: str = "en_US") -> dict[str, Any]:
        """Return the logged-in account's rank for a game and period."""
        return self._account.game.get_game_my_rank(game_id, period, language)

    async def async_get_game_my_rank(self, game_id: str, period: str = "all",
                                     language: str = "en_US") -> dict[str, Any]:
        return await self._account.game.async_get_game_my_rank(game_id, period, language)

    def get_game_leaderboard_entries(self, game_id: str, period: str = "all", page: int = 0,
                                     size: int = 10, game_version: int | None = None,
                                     language: str = "en_US") -> list[RankEntry]:
        """Return a page of game leaderboard rows as :class:RankEntry objects.

        Scores are Python integers and keep full precision; `display_value`
        contains the server's compact display string (for example `99.99Y`).
        """
        r = self.get_game_leaderboard(game_id, period, page, size, game_version, language)
        data = r.get("data")
        page_info = data.get("pageInfo") if isinstance(data, dict) else None
        items = page_info.get("data") if isinstance(page_info, dict) else None
        if not isinstance(items, list):
            items = []
        return [e for e in (RankEntry.from_dict(item) for item in items if item) if e is not None]

    async def async_get_game_leaderboard_entries(self, game_id: str, period: str = "all", page: int = 0,
                                                 size: int = 10, game_version: int | None = None,
                                                 language: str = "en_US") -> list[RankEntry]:
        r = await self.async_get_game_leaderboard(game_id, period, page, size, game_version, language)
        data = r.get("data")
        page_info = data.get("pageInfo") if isinstance(data, dict) else None
        items = page_info.get("data") if isinstance(page_info, dict) else None
        if not isinstance(items, list):
            items = []
        return [e for e in (RankEntry.from_dict(item) for item in items if item) if e is not None]